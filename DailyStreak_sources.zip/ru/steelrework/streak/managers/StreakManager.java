package ru.steelrework.streak.managers;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import ru.steelrework.streak.DailyStreakPlugin;
import ru.steelrework.streak.database.DatabaseManager;
import ru.steelrework.streak.models.PlayerStreak;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

public class StreakManager {
    
    private final DailyStreakPlugin plugin;
    private final DatabaseManager database;
    private final LanguageManager languageManager;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    public StreakManager(DailyStreakPlugin plugin, DatabaseManager database, LanguageManager languageManager) {
        this.plugin = plugin;
        this.database = database;
        this.languageManager = languageManager;
    }
    
    public DailyStreakPlugin getPlugin() {
        return plugin;
    }
    
    private ZoneId getTimeZone() {
        int offset = plugin.getConfig().getInt("timezone-offset", 3);
        return ZoneId.of(offset >= 0 ? "+" + offset : String.valueOf(offset));
    }
    
    private LocalDate getCurrentDate() {
        return LocalDate.now(getTimeZone());
    }
    
    private String getCurrentMonth() {
        return LocalDate.now(getTimeZone()).format(DateTimeFormatter.ofPattern("yyyy-MM"));
    }
    
    public void handlePlayerJoin(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerStreak streak = database.getPlayerStreak(uuid);
        LocalDate today = getCurrentDate();
        String todayStr = today.format(dateFormatter);
        
        if (streak == null) {
            // Новый игрок
            streak = new PlayerStreak(uuid, player.getName(), 1, todayStr, 0, getCurrentMonth());
            database.savePlayerStreak(streak);
            
            player.sendMessage(languageManager.formatDays(
                languageManager.get("streak-join-first"), 1));
            return;
        }
        
        // Обновить имя
        streak.setName(player.getName());
        
        // Проверить месяц для сброса восстановлений
        String currentMonth = getCurrentMonth();
        if (!currentMonth.equals(streak.getRestoresMonth())) {
            streak.setRestoresUsed(0);
            streak.setRestoresMonth(currentMonth);
        }
        
        LocalDate lastLogin = LocalDate.parse(streak.getLastLoginDate(), dateFormatter);
        long daysBetween = ChronoUnit.DAYS.between(lastLogin, today);
        
        if (daysBetween == 0) {
            // Уже заходил сегодня
            return;
        } else if (daysBetween == 1) {
            // Следующий день подряд
            streak.setCurrentStreak(streak.getCurrentStreak() + 1);
            streak.setLastLoginDate(todayStr);
            database.savePlayerStreak(streak);
            
            player.sendMessage(languageManager.formatDays(
                languageManager.get("streak-join")
                    .replace("{days}", String.valueOf(streak.getCurrentStreak())),
                streak.getCurrentStreak()));
        } else {
            // Пропустил день(дни) - огонёк погас
            int oldStreak = streak.getCurrentStreak();
            streak.setCurrentStreak(0);
            streak.setLastLoginDate(todayStr);
            database.savePlayerStreak(streak);
            
            if (oldStreak > 0) {
                player.sendMessage(languageManager.get("streak-expired"));
                
                // Уведомление в общий чат
                Bukkit.getScheduler().runTask(plugin, () -> {
                    Bukkit.broadcastMessage(languageManager.get("streak-expired-broadcast")
                        .replace("{player}", player.getName()));
                });
            }
        }
    }
    
    public boolean restoreStreak(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerStreak streak = database.getPlayerStreak(uuid);
        
        if (streak == null || streak.getCurrentStreak() > 0) {
            player.sendMessage(languageManager.get("nothing-to-restore"));
            return false;
        }
        
        int maxRestores = getMaxRestoresPerMonth();
        if (streak.getRestoresUsed() >= maxRestores) {
            player.sendMessage(languageManager.get("no-restores")
                .replace("{used}", String.valueOf(streak.getRestoresUsed()))
                .replace("{max}", String.valueOf(maxRestores)));
            return false;
        }
        
        // Восстановить огонёк
        LocalDate lastLogin = LocalDate.parse(streak.getLastLoginDate(), dateFormatter);
        LocalDate today = getCurrentDate();
        long daysBetween = ChronoUnit.DAYS.between(lastLogin, today);
        
        // Восстанавливаем предыдущий огонёк + 1 за сегодня
        int restoredStreak = Math.max(1, (int) daysBetween);
        streak.setCurrentStreak(restoredStreak);
        streak.setRestoresUsed(streak.getRestoresUsed() + 1);
        streak.setLastLoginDate(today.format(dateFormatter));
        database.savePlayerStreak(streak);
        
        player.sendMessage(languageManager.formatDays(
            languageManager.get("streak-restored")
                .replace("{days}", String.valueOf(restoredStreak)),
            restoredStreak));
        
        return true;
    }
    
    public void checkExpiredStreaks() {
        List<PlayerStreak> allStreaks = database.getAllStreaks();
        LocalDate today = getCurrentDate();
        
        for (PlayerStreak streak : allStreaks) {
            if (streak.getCurrentStreak() == 0) continue;
            
            LocalDate lastLogin = LocalDate.parse(streak.getLastLoginDate(), dateFormatter);
            long daysBetween = ChronoUnit.DAYS.between(lastLogin, today);
            
            if (daysBetween > 1) {
                // Огонёк погас
                streak.setCurrentStreak(0);
                database.savePlayerStreak(streak);
                
                Player player = Bukkit.getPlayer(streak.getUuid());
                if (player != null && player.isOnline()) {
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        player.sendMessage(languageManager.get("streak-expired"));
                        Bukkit.broadcastMessage(languageManager.get("streak-expired-broadcast")
                            .replace("{player}", player.getName()));
                    });
                }
            }
        }
    }
    
    public PlayerStreak getStreak(UUID uuid) {
        PlayerStreak streak = database.getPlayerStreak(uuid);
        if (streak == null) {
            return new PlayerStreak(uuid, "Unknown", 0, getCurrentDate().format(dateFormatter), 0, getCurrentMonth());
        }
        return streak;
    }
    
    public List<PlayerStreak> getTopStreaks(int limit) {
        return database.getTopStreaks(limit);
    }
    
    public int getMaxRestoresPerMonth() {
        return plugin.getConfig().getInt("max-restores-per-month", 2);
    }
    
    public void setStreak(UUID uuid, int amount) {
        PlayerStreak streak = database.getPlayerStreak(uuid);
        if (streak == null) {
            String name = Bukkit.getOfflinePlayer(uuid).getName();
            if (name == null) name = "Unknown";
            streak = new PlayerStreak(uuid, name, amount, getCurrentDate().format(dateFormatter), 0, getCurrentMonth());
        } else {
            streak.setCurrentStreak(amount);
            streak.setLastLoginDate(getCurrentDate().format(dateFormatter));
        }
        database.savePlayerStreak(streak);
    }
}

package ru.steelrework.streak.managers;

import org.bukkit.configuration.file.FileConfiguration;
import ru.steelrework.streak.DailyStreakPlugin;

import java.util.HashMap;
import java.util.Map;

public class LanguageManager {
    
    private final DailyStreakPlugin plugin;
    private final Map<String, String> messages = new HashMap<>();
    
    public LanguageManager(DailyStreakPlugin plugin) {
        this.plugin = plugin;
        loadMessages();
    }
    
    public void reload() {
        messages.clear();
        loadMessages();
    }
    
    private void loadMessages() {
        FileConfiguration config = plugin.getConfig();
        String lang = config.getString("language", "ru");
        
        if (lang.equalsIgnoreCase("ru")) {
            loadRussian();
        } else {
            loadEnglish();
        }
    }
    
    private void loadRussian() {
        messages.put("streak-join", "§6§l🔥 Огонёк: §e{days} {days_word}! §a§l+1 день §7(Заходи каждый день!)");
        messages.put("streak-join-first", "§6§l🔥 Огонёк: §e1 день! §7Заходи каждый день чтобы не потерять огонёк!");
        messages.put("streak-expired", "§c§l😢 Огонёк погас! §7Ты пропустил день. Используй §e/streak §7чтобы восстановить!");
        messages.put("streak-expired-broadcast", "§c§l😢 Огонёк игрока §e{player} §c§lпогас! §7Он пропустил день...");
        messages.put("streak-restored", "§a§l🎉 Огонёк восстановлен! §7Текущий огонёк: §e{days} {days_word}");
        messages.put("no-restores", "§c§lОшибка: §fУ вас не осталось восстановлений! §7({used}/{max} использовано в этом месяце)");
        messages.put("nothing-to-restore", "§c§lОшибка: §fВаш огонёк не погас, восстанавливать нечего!");
        
        messages.put("streak-info", "§6§l🔥 Огонёк игрока §e{player}§6§l: §e{days} {days_word}\n§7Восстановлений использовано: §f{restores}§7/§f{max_restores}");
        messages.put("streak-info-zero", "§7§l🌫️ У игрока §e{player} §7§lогонёк погас");
        
        messages.put("top-header", "§6§l━━━━━━ 🔥 ТОП ОГОНЬКОВ 🔥 ━━━━━━");
        messages.put("top-line", "§e#{position} §6{player} §7— §e{days} {days_word}");
        messages.put("top-empty", "§7Пока никто не зажёг огонёк...");
        
        messages.put("config-reloaded", "§a§l✓ Конфигурация перезагружена!");
        messages.put("admin-set", "§a§l✓ Огонёк игрока §e{player} §a§lустановлен на §e{days} {days_word}");
        messages.put("admin-add", "§a§l✓ Добавлено §e{days} {days_word} §a§lигроку §e{player}§a§l. Итого: §e{total}");
        messages.put("admin-remove", "§a§l✓ Отнято §e{days} {days_word} §a§lу игрока §e{player}§a§l. Осталось: §e{total}");
        
        messages.put("player-not-found", "§c§lОшибка: §fИгрок не найден!");
        messages.put("no-permission", "§c§lОшибка: §fУ вас нет прав!");
        messages.put("only-players", "§c§lОшибка: §fКоманда только для игроков!");
        
        messages.put("day", "день");
        messages.put("days-2-4", "дня");
        messages.put("days-5+", "дней");
    }
    
    private void loadEnglish() {
        messages.put("streak-join", "§6§l🔥 Streak: §e{days} {days_word}! §a§l+1 day §7(Login daily!)");
        messages.put("streak-join-first", "§6§l🔥 Streak: §e1 day! §7Login every day to keep your streak!");
        messages.put("streak-expired", "§c§l😢 Streak lost! §7You missed a day. Use §e/streak §7to restore!");
        messages.put("streak-expired-broadcast", "§c§l😢 Player §e{player}§c§l's streak expired! §7They missed a day...");
        messages.put("streak-restored", "§a§l🎉 Streak restored! §7Current streak: §e{days} {days_word}");
        messages.put("no-restores", "§c§lError: §fNo restores left! §7({used}/{max} used this month)");
        messages.put("nothing-to-restore", "§c§lError: §fYour streak is active, nothing to restore!");
        
        messages.put("streak-info", "§6§l🔥 {player}'s streak§6§l: §e{days} {days_word}\n§7Restores used: §f{restores}§7/§f{max_restores}");
        messages.put("streak-info-zero", "§7§l🌫️ Player §e{player} §7§lhas no active streak");
        
        messages.put("top-header", "§6§l━━━━━━ 🔥 TOP STREAKS 🔥 ━━━━━━");
        messages.put("top-line", "§e#{position} §6{player} §7— §e{days} {days_word}");
        messages.put("top-empty", "§7No streaks yet...");
        
        messages.put("config-reloaded", "§a§l✓ Configuration reloaded!");
        messages.put("admin-set", "§a§l✓ Set §e{player}§a§l's streak to §e{days} {days_word}");
        messages.put("admin-add", "§a§l✓ Added §e{days} {days_word} §a§lto §e{player}§a§l. Total: §e{total}");
        messages.put("admin-remove", "§a§l✓ Removed §e{days} {days_word} §a§lfrom §e{player}§a§l. Remaining: §e{total}");
        
        messages.put("player-not-found", "§c§lError: §fPlayer not found!");
        messages.put("no-permission", "§c§lError: §fNo permission!");
        messages.put("only-players", "§c§lError: §fPlayers only!");
        
        messages.put("day", "day");
        messages.put("days-2-4", "days");
        messages.put("days-5+", "days");
    }
    
    public String get(String key) {
        String message = messages.getOrDefault(key, "§cMissing message: " + key);
        return message.replace("{days_word}", getDaysWord(0));
    }
    
    private String getDaysWord(int days) {
        String lang = plugin.getConfig().getString("language", "ru");
        
        if (lang.equalsIgnoreCase("ru")) {
            int lastDigit = days % 10;
            int lastTwoDigits = days % 100;
            
            if (lastTwoDigits >= 11 && lastTwoDigits <= 14) {
                return messages.get("days-5+");
            }
            if (lastDigit == 1) {
                return messages.get("day");
            }
            if (lastDigit >= 2 && lastDigit <= 4) {
                return messages.get("days-2-4");
            }
            return messages.get("days-5+");
        } else {
            return days == 1 ? messages.get("day") : messages.get("days-2-4");
        }
    }
    
    public String formatDays(String message, int days) {
        return message.replace("{days_word}", getDaysWord(days));
    }
}

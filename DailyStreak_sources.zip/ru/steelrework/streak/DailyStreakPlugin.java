package ru.steelrework.streak;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import ru.steelrework.streak.commands.*;
import ru.steelrework.streak.database.DatabaseManager;
import ru.steelrework.streak.listeners.PlayerJoinListener;
import ru.steelrework.streak.managers.LanguageManager;
import ru.steelrework.streak.managers.StreakManager;

public class DailyStreakPlugin extends JavaPlugin {
    
    private DatabaseManager databaseManager;
    private StreakManager streakManager;
    private LanguageManager languageManager;
    
    @Override
    public void onEnable() {
        saveDefaultConfig();
        
        databaseManager = new DatabaseManager(this);
        databaseManager.connect();
        
        languageManager = new LanguageManager(this);
        streakManager = new StreakManager(this, databaseManager, languageManager);
        
        getCommand("streak").setExecutor(new StreakCommand(streakManager, languageManager));
        getCommand("streaktop").setExecutor(new StreakTopCommand(streakManager, languageManager));
        getCommand("streakreload").setExecutor(new StreakReloadCommand(this, languageManager));
        getCommand("streakset").setExecutor(new StreakSetCommand(streakManager, languageManager));
        getCommand("streakadd").setExecutor(new StreakAddCommand(streakManager, languageManager));
        getCommand("streakremove").setExecutor(new StreakRemoveCommand(streakManager, languageManager));
        
        Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(this, streakManager, languageManager), this);
        
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
            streakManager.checkExpiredStreaks();
        }, 6000L, 6000L);
        
        getLogger().info("DailyStreak плагин успешно запущен!");
    }
    
    @Override
    public void onDisable() {
        if (databaseManager != null) {
            databaseManager.disconnect();
        }
        getLogger().info("DailyStreak плагин остановлен!");
    }
    
    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }
    
    public StreakManager getStreakManager() {
        return streakManager;
    }
    
    public LanguageManager getLanguageManager() {
        return languageManager;
    }
}

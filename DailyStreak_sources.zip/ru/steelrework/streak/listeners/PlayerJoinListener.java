package ru.steelrework.streak.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import ru.steelrework.streak.DailyStreakPlugin;
import ru.steelrework.streak.managers.LanguageManager;
import ru.steelrework.streak.managers.StreakManager;

public class PlayerJoinListener implements Listener {
    
    private final DailyStreakPlugin plugin;
    private final StreakManager streakManager;
    private final LanguageManager languageManager;
    
    public PlayerJoinListener(DailyStreakPlugin plugin, StreakManager streakManager, LanguageManager languageManager) {
        this.plugin = plugin;
        this.streakManager = streakManager;
        this.languageManager = languageManager;
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            streakManager.handlePlayerJoin(event.getPlayer());
        });
    }
}

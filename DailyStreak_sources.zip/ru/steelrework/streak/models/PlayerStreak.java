package ru.steelrework.streak.models;

import java.util.UUID;

public class PlayerStreak {
    
    private final UUID uuid;
    private String name;
    private int currentStreak;
    private String lastLoginDate;
    private int restoresUsed;
    private String restoresMonth;
    
    public PlayerStreak(UUID uuid, String name, int currentStreak, String lastLoginDate, int restoresUsed, String restoresMonth) {
        this.uuid = uuid;
        this.name = name;
        this.currentStreak = currentStreak;
        this.lastLoginDate = lastLoginDate;
        this.restoresUsed = restoresUsed;
        this.restoresMonth = restoresMonth;
    }
    
    public UUID getUuid() {
        return uuid;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getCurrentStreak() {
        return currentStreak;
    }
    
    public void setCurrentStreak(int currentStreak) {
        this.currentStreak = currentStreak;
    }
    
    public String getLastLoginDate() {
        return lastLoginDate;
    }
    
    public void setLastLoginDate(String lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }
    
    public int getRestoresUsed() {
        return restoresUsed;
    }
    
    public void setRestoresUsed(int restoresUsed) {
        this.restoresUsed = restoresUsed;
    }
    
    public String getRestoresMonth() {
        return restoresMonth;
    }
    
    public void setRestoresMonth(String restoresMonth) {
        this.restoresMonth = restoresMonth;
    }
}

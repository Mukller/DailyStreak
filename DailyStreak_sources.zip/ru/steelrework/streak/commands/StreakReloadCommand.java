package ru.steelrework.streak.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import ru.steelrework.streak.DailyStreakPlugin;
import ru.steelrework.streak.managers.LanguageManager;

public class StreakReloadCommand implements CommandExecutor {
    
    private final DailyStreakPlugin plugin;
    private final LanguageManager lang;
    
    public StreakReloadCommand(DailyStreakPlugin plugin, LanguageManager lang) {
        this.plugin = plugin;
        this.lang = lang;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("dailystreak.admin")) {
            sender.sendMessage(lang.get("no-permission"));
            return true;
        }
        
        plugin.reloadConfig();
        lang.reload();
        
        sender.sendMessage(lang.get("config-reloaded"));
        return true;
    }
}

package ru.steelrework.streak.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.steelrework.streak.managers.LanguageManager;
import ru.steelrework.streak.managers.StreakManager;
import ru.steelrework.streak.models.PlayerStreak;

public class StreakCommand implements CommandExecutor {
    
    private final StreakManager streakManager;
    private final LanguageManager lang;
    
    public StreakCommand(StreakManager streakManager, LanguageManager lang) {
        this.streakManager = streakManager;
        this.lang = lang;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(lang.get("only-players"));
                return true;
            }
            target = (Player) sender;
        } else {
            target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                sender.sendMessage(lang.get("player-not-found"));
                return true;
            }
        }
        
        PlayerStreak streak = streakManager.getStreak(target.getUniqueId());
        
        if (streak.getCurrentStreak() == 0) {
            sender.sendMessage(lang.get("streak-info-zero")
                .replace("{player}", target.getName()));
        } else {
            sender.sendMessage(lang.formatDays(
                lang.get("streak-info")
                    .replace("{player}", target.getName())
                    .replace("{days}", String.valueOf(streak.getCurrentStreak()))
                    .replace("{restores}", String.valueOf(streak.getRestoresUsed()))
                    .replace("{max_restores}", String.valueOf(streakManager.getMaxRestoresPerMonth())),
                streak.getCurrentStreak()));
        }
        
        return true;
    }
}

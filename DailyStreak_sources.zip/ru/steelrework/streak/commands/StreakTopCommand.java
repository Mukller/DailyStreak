package ru.steelrework.streak.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import ru.steelrework.streak.managers.LanguageManager;
import ru.steelrework.streak.managers.StreakManager;
import ru.steelrework.streak.models.PlayerStreak;

import java.util.List;

public class StreakTopCommand implements CommandExecutor {
    
    private final StreakManager streakManager;
    private final LanguageManager lang;
    
    public StreakTopCommand(StreakManager streakManager, LanguageManager lang) {
        this.streakManager = streakManager;
        this.lang = lang;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Bukkit.getScheduler().runTaskAsynchronously(streakManager.getPlugin(), () -> {
            List<PlayerStreak> top = streakManager.getTopStreaks(10);
            
            sender.sendMessage(lang.get("top-header"));
            
            if (top.isEmpty()) {
                sender.sendMessage(lang.get("top-empty"));
                return;
            }
            
            int position = 1;
            for (PlayerStreak streak : top) {
                String playerName = Bukkit.getOfflinePlayer(streak.getUuid()).getName();
                if (playerName == null) playerName = "Unknown";
                
                sender.sendMessage(lang.formatDays(
                    lang.get("top-line")
                        .replace("{position}", String.valueOf(position))
                        .replace("{player}", playerName)
                        .replace("{days}", String.valueOf(streak.getCurrentStreak())),
                    streak.getCurrentStreak()));
                position++;
            }
        });
        
        return true;
    }
}

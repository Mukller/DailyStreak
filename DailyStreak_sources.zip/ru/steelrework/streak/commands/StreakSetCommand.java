package ru.steelrework.streak.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.steelrework.streak.managers.LanguageManager;
import ru.steelrework.streak.managers.StreakManager;

public class StreakSetCommand implements CommandExecutor {
    
    private final StreakManager streakManager;
    private final LanguageManager lang;
    
    public StreakSetCommand(StreakManager streakManager, LanguageManager lang) {
        this.streakManager = streakManager;
        this.lang = lang;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("dailystreak.admin")) {
            sender.sendMessage(lang.get("no-permission"));
            return true;
        }
        
        if (args.length != 2) {
            sender.sendMessage("§c§lИспользование: §e/streakset <игрок> <число>");
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage(lang.get("player-not-found"));
            return true;
        }
        
        int amount;
        try {
            amount = Integer.parseInt(args[1]);
            if (amount < 0) {
                sender.sendMessage("§c§lОшибка: §fЧисло должно быть положительным!");
                return true;
            }
        } catch (NumberFormatException e) {
            sender.sendMessage("§c§lОшибка: §fУкажите корректное число!");
            return true;
        }
        
        streakManager.setStreak(target.getUniqueId(), amount);
        sender.sendMessage(lang.formatDays(
            lang.get("admin-set")
                .replace("{player}", target.getName())
                .replace("{days}", String.valueOf(amount)),
            amount));
        
        return true;
    }
}

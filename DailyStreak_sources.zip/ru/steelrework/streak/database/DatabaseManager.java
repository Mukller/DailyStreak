package ru.steelrework.streak.database;

import ru.steelrework.streak.DailyStreakPlugin;
import ru.steelrework.streak.models.PlayerStreak;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DatabaseManager {
    
    private final DailyStreakPlugin plugin;
    private Connection connection;
    
    public DatabaseManager(DailyStreakPlugin plugin) {
        this.plugin = plugin;
    }
    
    public boolean connect() {
        try {
            File dataFolder = plugin.getDataFolder();
            if (!dataFolder.exists()) {
                dataFolder.mkdirs();
            }
            
            File dbFile = new File(dataFolder, "streaks.db");
            String url = "jdbc:sqlite:" + dbFile.getAbsolutePath();
            
            connection = DriverManager.getConnection(url);
            createTables();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("Database connection error: " + e.getMessage());
            return false;
        }
    }
    
    private void createTables() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS player_streaks (" +
                "uuid TEXT PRIMARY KEY," +
                "name TEXT NOT NULL," +
                "current_streak INTEGER DEFAULT 0," +
                "last_login_date TEXT," +
                "restores_used INTEGER DEFAULT 0," +
                "restores_month TEXT" +
                ")";
        
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
    }
    
    public PlayerStreak getPlayerStreak(UUID uuid) {
        String sql = "SELECT * FROM player_streaks WHERE uuid = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, uuid.toString());
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new PlayerStreak(
                    UUID.fromString(rs.getString("uuid")),
                    rs.getString("name"),
                    rs.getInt("current_streak"),
                    rs.getString("last_login_date"),
                    rs.getInt("restores_used"),
                    rs.getString("restores_month")
                );
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Error getting player streak: " + e.getMessage());
        }
        
        return null;
    }
    
    public void savePlayerStreak(PlayerStreak streak) {
        String sql = "INSERT OR REPLACE INTO player_streaks (uuid, name, current_streak, last_login_date, restores_used, restores_month) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, streak.getUuid().toString());
            stmt.setString(2, streak.getName());
            stmt.setInt(3, streak.getCurrentStreak());
            stmt.setString(4, streak.getLastLoginDate());
            stmt.setInt(5, streak.getRestoresUsed());
            stmt.setString(6, streak.getRestoresMonth());
            stmt.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("Error saving player streak: " + e.getMessage());
        }
    }
    
    public List<PlayerStreak> getTopStreaks(int limit) {
        List<PlayerStreak> topStreaks = new ArrayList<>();
        String sql = "SELECT * FROM player_streaks WHERE current_streak > 0 ORDER BY current_streak DESC LIMIT ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, limit);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                topStreaks.add(new PlayerStreak(
                    UUID.fromString(rs.getString("uuid")),
                    rs.getString("name"),
                    rs.getInt("current_streak"),
                    rs.getString("last_login_date"),
                    rs.getInt("restores_used"),
                    rs.getString("restores_month")
                ));
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Error getting top streaks: " + e.getMessage());
        }
        
        return topStreaks;
    }
    
    public List<PlayerStreak> getAllStreaks() {
        List<PlayerStreak> allStreaks = new ArrayList<>();
        String sql = "SELECT * FROM player_streaks";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                allStreaks.add(new PlayerStreak(
                    UUID.fromString(rs.getString("uuid")),
                    rs.getString("name"),
                    rs.getInt("current_streak"),
                    rs.getString("last_login_date"),
                    rs.getInt("restores_used"),
                    rs.getString("restores_month")
                ));
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Error getting all streaks: " + e.getMessage());
        }
        
        return allStreaks;
    }
    
    public void disconnect() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Error closing database: " + e.getMessage());
        }
    }
}
